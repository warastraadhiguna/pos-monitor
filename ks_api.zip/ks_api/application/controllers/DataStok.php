<?php

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class DataStok extends REST_Controller
{
    public function __construct($config = 'rest')
    {
        parent::__construct($config);
        $this->load->database();
    }

    public function index_post()
    {
        $data = $this->post('data');

        try {
            $this->db->trans_begin();

            $deletedData = array();
            foreach($data as $singleData) {
                array_push($deletedData, $singleData["idStok"]);
            }

            $this->db->where_in('idStok', $deletedData);
            $this->db->delete('tstok');

            if($this->db->insert_batch('tstok', $data)) {
                $this->db->trans_commit();
                $this->response("success", 200);
            }
        } catch (Exception $e) {
            $this->db->trans_rollback();
            $this->response(array('status' => 'fail', 502));
        }
    }

    public function index_put()
    {
        $data = $this->put('data');
        $deletedData = array();
        foreach($data as $singleData) {
            array_push($deletedData, $singleData["idStok"]);
        }


        $this->db->where_in('idStok', $deletedData);
        $this->db->delete('tstok');
        $this->db->trans_commit();
        $this->response($data, 200);

        return;
    }

    public function index_delete()
    {
        $data = $this->delete('data');

        try {
            $this->db->trans_begin();

            $dataList = explode("#", $data);
            $this->db->where_in('idStok', $dataList);
            if($this->db->delete('tstok')) {
                $this->db->trans_commit();
                $this->response("success", 200);
            }
        } catch (Exception $e) {
            $this->db->trans_rollback();
            $this->response(array('status' => 'fail', 502));
        }
    }
}
