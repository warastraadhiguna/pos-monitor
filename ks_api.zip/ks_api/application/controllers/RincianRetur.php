<?php

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class RincianRetur extends REST_Controller
{
    public function __construct($config = 'rest')
    {
        parent::__construct($config);
        $this->load->database();
    }

    public function index_post()
    {
        $data = $this->post('data');

        try {
            $this->db->trans_begin();

            $deletedData = array();
            foreach($data as $singleData) {
                array_push($deletedData, $singleData["noRetur"]);
            }

            $this->db->where_in('noRetur', $deletedData);
            $this->db->delete('trincianretur');

            if($this->db->insert_batch('trincianretur', $data)) {
                $this->db->trans_commit();
                $this->response("success", 200);
            }
        } catch (Exception $e) {
            $this->db->trans_rollback();
            $this->response(array('status' => 'fail', 502));
        }
    }
}
