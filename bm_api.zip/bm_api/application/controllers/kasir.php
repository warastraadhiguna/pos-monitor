<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Kasir extends REST_Controller  {
    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }
	
    function index_get() {
        $id_nota_penjualan = $this->get('id_nota_penjualan');
        $this->response($id_nota_penjualan, 200);
	}		
	
    function index_post() {
        $data = $this->post('data');
    
        try 
        { 
            $this->db->trans_begin();
            
            $deletedData = array();
            foreach($data as $singleData)
            {
                array_push($deletedData,$singleData["noUser"]);       
            }
            
            $this->db->where_in('noUser', $deletedData);
            $this->db->delete('tKasir');
            
            if($this->db->insert_batch('tKasir', $data))
            {       
                $this->db->trans_commit();
                $this->response("success", 200);
            }
        } 
        catch (Exception $e) {
            $this->db->trans_rollback();
            $this->response(array('status' => 'fail', 502));
        }
    } 

    function index_delete() {
        $data = $this->delete('data');
    
        try 
        { 
            $this->db->trans_begin();

            $dataList = explode("#", $data);
            $this->db->where_in('tKasir', $dataList);
            if($this->db->delete('tKasir'))
            {       
                $this->db->trans_commit();
                $this->response("success", 200);
            }
        } 
        catch (Exception $e) {
            $this->db->trans_rollback();
            $this->response(array('status' => 'fail', 502));
        }
    }       
}
