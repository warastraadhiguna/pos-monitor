<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class CicilanHutang extends REST_Controller  {
    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }
	
    function index_post() {
        $data = $this->post('data');
    
        try 
        { 
            $this->db->trans_begin();
                        
            if($this->db->insert_batch('tCicilanHutang', $data))
            {       
                $this->db->trans_commit();
                $this->response("success", 200);
            }
        } 
        catch (Exception $e) {
            $this->db->trans_rollback();
            $this->response(array('status' => 'fail', 502));
        }
    } 
}
