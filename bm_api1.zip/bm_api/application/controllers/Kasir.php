<?php

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Kasir extends REST_Controller
{
    public function __construct($config = 'rest')
    {
        parent::__construct($config);
        $this->load->database();
    }

    public function index_get()
    {
        $id_nota_penjualan = $this->get('id_nota_penjualan');
        $this->response($id_nota_penjualan, 200);
    }

    public function index_post()
    {
        $data = $this->post('data');

        try {
            $this->db->trans_begin();

            $deletedData = array();
            foreach($data as $singleData) {
                array_push($deletedData, $singleData["noUser"]);
            }

            $this->db->where_in('noUser', $deletedData);
            $this->db->delete('tkasir');

            if($this->db->insert_batch('tkasir', $data)) {
                $this->db->trans_commit();
                $this->response("success", 200);
            }
        } catch (Exception $e) {
            $this->db->trans_rollback();
            $this->response(array('status' => 'fail', 502));
        }
    }

    public function index_delete()
    {
        $data = $this->delete('data');

        try {
            $this->db->trans_begin();

            $dataList = explode("#", $data);
            $this->db->where_in('tkasir', $dataList);
            if($this->db->delete('tkasir')) {
                $this->db->trans_commit();
                $this->response("success", 200);
            }
        } catch (Exception $e) {
            $this->db->trans_rollback();
            $this->response(array('status' => 'fail', 502));
        }
    }
}